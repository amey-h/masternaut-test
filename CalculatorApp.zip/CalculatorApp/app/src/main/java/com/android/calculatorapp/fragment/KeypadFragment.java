package com.android.calculatorapp.fragment;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;

import com.android.calculatorapp.MainActivity;
import com.android.calculatorapp.R;
import com.android.calculatorapp.adapter.KeyGridAdapter;
import com.android.calculatorapp.utils.Utils;

/**
 * Created by Amey on 6/6/2016.
 */
public class KeypadFragment extends Fragment implements KeyGridAdapter.IButtonClicked {

    /**
     * The constant TAG.
     */
    private static final String TAG = KeypadFragment.class.getSimpleName();
    /**
     * The M grid view.
     */
    private GridView mGridView;
    /**
     * The M listener.
     */
    private IFragmentInteractionListener mListener;
    /**
     * The M temp str.
     */
    private String mTempStr = "";
    /**
     * The M first number.
     */
    private long mFirstNumber, /**
     * The M second number.
     */
    mSecondNumber;

    /**
     * Instantiates a new Keypad fragment.
     */
    public KeypadFragment() {
        // empty constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof IFragmentInteractionListener) {
            mListener = (IFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " implement IFragmentInteractionListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_keypad, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mGridView = (GridView) view.findViewById(R.id.grid_view);

        KeyGridAdapter adapter = new KeyGridAdapter(getActivity(), this);
        mGridView.setAdapter(adapter);

    }

    @Override
    public void onButtonClicked(String value) {
        Log.i(TAG, "clicked value = " +value);
        updateString(value);
    }


    /**
     * Update string.
     *
     * @param value the value
     */
    private void updateString(String value) {
        mTempStr = mTempStr + value;

        if (mListener != null) {
            if (mTempStr.startsWith("+") || mTempStr.startsWith("=") ) {
                Utils.showAlertMessage(getActivity(), getResources().getString(R.string.warning_1));
                mTempStr = "";
            } else if (mTempStr.endsWith("+=")) {
                Utils.showAlertMessage(getActivity(), getResources().getString(R.string.warning_2));
                mTempStr = mTempStr.substring(0, mTempStr.length() - 1);
            } else if (mTempStr.contains("++")) {
                mTempStr = mTempStr.replace("++", "+");
            } else {
                Log.i(TAG, "Expression: "+mTempStr);

                if (mTempStr.length() == 1) {
                    mListener.onKeyPressed("", 1);
                    mListener.onKeyPressed("", 2);
                }
                if (mTempStr.contains("=")) {
                    // starting service.
                    ((MainActivity) getActivity()).getTotalSum(mFirstNumber, mSecondNumber);
                    mTempStr = "";
                } else {
                    String[] numbers = mTempStr.split("[+]");
                    if (numbers.length == 1) {

                        try {
                            mFirstNumber = Long.parseLong(numbers[0]);
                            mListener.onKeyPressed(numbers[0], 1);
                        } catch (NumberFormatException ne) {
                            Utils.showAlertMessage(getActivity(), getResources().getString(R.string.number_format_exception));
                            mListener.onKeyPressed("", 1);
                            mFirstNumber = 0;
                            mTempStr = "";
                        }
                    }
                    if (numbers.length == 2) {
                        try {

                            mSecondNumber = Long.parseLong(numbers[1]);
                            mListener.onKeyPressed(numbers[1], 2);

                        } catch (NumberFormatException ne) {
                            Utils.showAlertMessage(getActivity(), getResources().getString(R.string.number_format_exception));
                            mListener.onKeyPressed("", 2);
                            mSecondNumber = 0;
                            mTempStr = mFirstNumber + "+";
                        }

                    }
                }

            }
        }
    }


    /**
     * The interface Fragment interaction listener.
     */
    public interface IFragmentInteractionListener {

        /**
         * On key pressed.
         *
         * @param value    the value
         * @param position the position
         */
        void onKeyPressed(String value, int position);
    }


    @Override
    public void onDetach() {
        super.onDetach();
        Log.i(TAG, "onDetach");
        mListener = null;
    }

}
