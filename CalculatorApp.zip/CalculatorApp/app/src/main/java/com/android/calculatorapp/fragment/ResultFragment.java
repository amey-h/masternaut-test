package com.android.calculatorapp.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.calculatorapp.MainActivity;
import com.android.calculatorapp.R;
import com.android.calculatorapp.utils.Utils;

import java.math.BigInteger;

/**
 * Created by Amey on 6/6/2016.
 */
public class ResultFragment extends Fragment {

    /**
     * The constant TAG.
     */
    private static final String TAG = ResultFragment.class.getSimpleName();
    /**
     * The M first num text view.
     */
    private TextView mFirstNumTextView, /**
     * The M second num text view.
     */
    mSecondNumTextView, /**
     * The M result text view.
     */
    mResultTextView;

    /**
     * Instantiates a new Result fragment.
     */
    public ResultFragment() {
        // empty Constructor.
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_result, container, false);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFirstNumTextView = (TextView) view.findViewById(R.id.text_first_number);
        mSecondNumTextView = (TextView) view.findViewById(R.id.text_second_number);
        mResultTextView = (TextView) view.findViewById(R.id.text_result);
    }

    /**
     * Update result.
     *
     * @param total the total
     */
    public void updateResult(long total) {
        mResultTextView.setText("" + total);
    }

    /**
     * Update text.
     *
     * @param value    the value
     * @param position the position
     */
    public void updateText(String value, int position) {
        Log.i(TAG, "Text Value: " + value);
        if (value != null) {

            if(position == 1) {
                mFirstNumTextView.setText(value);
                if(value.equalsIgnoreCase("")) {
                    mResultTextView.setText("");
                }
            } else {
                mSecondNumTextView.setText(value);
                if(value.equalsIgnoreCase("")) {
                    mResultTextView.setText("");
                }

            }
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Log.i(TAG, "onDetach");
    }
}
