package com.android.calculatorapp;


import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.android.calculatorapp.fragment.KeypadFragment;
import com.android.calculatorapp.fragment.ResultFragment;
import com.android.calculatorapp.utils.Const;
import com.android.calculatorapp.utils.Utils;

/**
 * The class Main activity.
 */
public class MainActivity extends AppCompatActivity implements KeypadFragment.IFragmentInteractionListener {


    /**
     * The constant TAG.
     */
    private static final String TAG = MainActivity.class.getSimpleName();
    /**
     * The Result fragment.
     */
    private Fragment resultFragment;
    /**
     * The Input messenger.
     */
    private Messenger inputMessenger = null;
    /**
     * The M bound.
     */
    private boolean mBound;
    /**
     * The M number 1.
     */
    private long mNumber1, /**
     * The M number 2.
     */
    mNumber2;
    /**
     * The M output messenger.
     */
    final Messenger mOutputMessenger = new Messenger(new IncomingMessageHandler());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultFragment = getSupportFragmentManager().findFragmentById(R.id.result_fragment);
    }

    /**
     * Gets total sum.
     *
     * @param firstNumber  the first number
     * @param secondNumber the second number
     */
    public void getTotalSum(long firstNumber, long secondNumber) {

        mNumber1 = firstNumber;
        mNumber2 = secondNumber;
        Intent intent = new Intent();
        intent.setClassName(getResources().getString(R.string.package_name),
                getResources().getString(R.string.full_class_name));
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
    }

    /**
     * The M ServiceConnection.
     */
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {

            Log.d(TAG, "Service Connected");
            inputMessenger = new Messenger(service);
            mBound = true;

            Message msg = Message.obtain(null, Const.MESSAGE_ADD, 0, 0);
            msg.replyTo = mOutputMessenger;

            Bundle bundle = new Bundle();
            bundle.putLong(getResources().getString(R.string.number1), mNumber1);
            bundle.putLong(getResources().getString(R.string.number2), mNumber2);
            msg.setData(bundle);

            try {
                inputMessenger.send(msg);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        public void onServiceDisconnected(ComponentName className) {

            inputMessenger = null;
            mBound = false;
        }
    };

    /**
     * The class Incoming message handler.
     */
    class IncomingMessageHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case Const.MESSAGE_SUM:
                    Bundle bundle = msg.getData();

                    long total = bundle.getLong(getResources().getString(R.string.total));
                    if(total < 0) {
                        Utils.showAlertMessage(MainActivity.this,
                                getResources().getString(R.string.number_format_exception));
                    } else {
                        ((ResultFragment) resultFragment).updateResult(total);
                    }
                    mNumber1 = 0;
                    mNumber2 = 0;

                    if (mBound) {
                        unbindService(mConnection);
                        mBound = false;
                    }
                    break;
            }
        }
    }

    @Override
    public void onKeyPressed(String value, int position) {
        ((ResultFragment) resultFragment).updateText(value, position);
    }
}
