package com.android.calculatorapp.utils;

/**
 * Created by Amey on 6/6/2016.
 */
public class Const {

    /**
     * The constant MESSAGE_ADD.
     */
    public static final int MESSAGE_ADD = 1;
    /**
     * The constant MESSAGE_SUM.
     */
    public static final int MESSAGE_SUM = 2;


}
