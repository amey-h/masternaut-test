package com.android.calculatorapp.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Toast;

import com.android.calculatorapp.R;
import com.android.calculatorapp.fragment.KeypadFragment;
import com.android.calculatorapp.utils.Const;

/**
 * Created by Amey on 6/6/2016.
 */
public class KeyGridAdapter extends BaseAdapter {

    /**
     * The constant TAG.
     */
    private static String TAG = KeyGridAdapter.class.getSimpleName();
    /**
     * The M context.
     */
    private Context mContext;
    /**
     * The M numbers.
     */
    private String[] mNumbers;
    /**
     * The Button listener.
     */
    private IButtonClicked buttonListener;

    /**
     * Instantiates a new Key grid adapter.
     *
     * @param c        the c
     * @param fragment the fragment
     */
    public KeyGridAdapter(Context c, KeypadFragment fragment) {

        mContext = c;
        mNumbers = mContext.getResources().getStringArray(R.array.numbers);
        try {
            buttonListener = (IButtonClicked) fragment;
        } catch (ClassCastException e) {
            throw new ClassCastException("Exception");
        }
    }

    @Override
    public int getCount() {
        return mNumbers.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Button button = new Button(mContext);
        button.setText(mNumbers[position]);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = ((Button)v).getText().toString();
                buttonListener.onButtonClicked(value);
            }
        });
        convertView = button;
        convertView.setId(position);
        return convertView;
    }

    /**
     * The interface Button clicked.
     */
    public interface IButtonClicked {

        /**
         * On button clicked.
         *
         * @param value the value
         */
        void onButtonClicked(String value);
    }
}
