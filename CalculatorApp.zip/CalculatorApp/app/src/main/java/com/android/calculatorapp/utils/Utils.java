package com.android.calculatorapp.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.android.calculatorapp.R;

/**
 * Created by Amey on 6/6/2016.
 */
public class Utils {

    /**
     * Show alert message.
     *
     * @param context the context
     * @param message the message
     */
    public static void showAlertMessage(Context context, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton(context.getResources().getString(R.string.ok_label),
                        new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
