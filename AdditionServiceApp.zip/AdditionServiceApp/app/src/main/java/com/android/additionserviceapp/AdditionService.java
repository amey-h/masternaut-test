package com.android.additionserviceapp;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

/**
 * Created by Amey on 6/6/2016.
 */
public class AdditionService extends Service {

    /**
     * The constant TAG.
     */
    private static final String TAG = AdditionService.class.getSimpleName();
    /**
     * The constant MESSAGE_ADDITION.
     */
    private static final int MESSAGE_ADDITION = 1;
    /**
     * The constant MESSAGE_SUM.
     */
    private static final int MESSAGE_SUM = 2;
    /**
     * The Output messenger.
     */
    private Messenger outputMessenger;

    /**
     * Instantiates a new Addition service.
     */
    public AdditionService() {
        // empty constructor.
    }


    /**
     * The class Incoming message handler.
     */
    class IncomingMessageHandler extends Handler {

        @Override
        public void handleMessage(Message msg) {

            Log.d(TAG, "binding service");

            switch (msg.what) {
                case MESSAGE_ADDITION:
                    try {
                        outputMessenger = msg.replyTo;
                        Bundle inputBundle = msg.getData();
                        long number1 = inputBundle.getLong("number1");
                        long number2 = inputBundle.getLong("number2");
                        Log.d(TAG, "Number1: " + number1);
                        Log.d(TAG, "Number2: " + number2);
                        long total;
                        if ((number1 + number2) <= Long.MAX_VALUE) {
                            total = number1 + number2;
                        } else {
                            total = -1;
                        }
                        Message newMsg = new Message();
                        newMsg.what = MESSAGE_SUM;

                        Bundle outputBundle = new Bundle();
                        outputBundle.putLong("total_sum", total);
                        newMsg.setData(outputBundle);
                        outputMessenger.send(newMsg);

                    } catch (RemoteException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        Log.w(TAG, "Exception: " + e);
                    }
                    break;

                default:
                    super.handleMessage(msg);

            }

        }
    }

    /**
     * The Input messenger.
     */
    Messenger inputMessenger = new Messenger(new IncomingMessageHandler());

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return inputMessenger.getBinder();
    }
}
